package com.balazsholczer.solid;

public interface ElectricVehicle {
	public void speed();
	public void chargeBattery();
}
