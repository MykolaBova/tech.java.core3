﻿/// <autosync enabled="true" />
/// <reference path="bootstrap.min.js" />
/// <reference path="jquery.validate.min.js" />
/// <reference path="jquery.validate.unobtrusive.min.js" />
/// <reference path="jquery-2.2.0.js" />
/// <reference path="jquery-2.2.0.min.js" />
/// <reference path="respond.matchmedia.addlistener.min.js" />
/// <reference path="respond.min.js" />
