package com.balazsholczer.solid;

public interface NormalVehicle {
	public void speed();
	public void addFuel();
}
