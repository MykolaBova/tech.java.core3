package com.factory;

public interface Algorithm {
	public void solve();
}
