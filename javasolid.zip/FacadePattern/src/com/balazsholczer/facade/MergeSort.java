package com.balazsholczer.facade;

public class MergeSort implements Algorithm {

	@Override
	public void sort() {
		System.out.println("Mergesort...");
	}
}
