package com.balazsholczer.solid;

public class BalancedTree implements Tree, IBalancedTree {

	@Override
	public int findMax() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int findMin() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int traverse() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void rightRotation() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void leftRotation() {
		// TODO Auto-generated method stub
		
	}


}
