package com.balazsholczer.solid;

public interface Sorter {
	public void sort();
}
